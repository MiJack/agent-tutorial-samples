# Pi Web Chat 教程配套源码

本包对应《给本地 AI Agent 装上 WebUI》教程。源码采用官方 AI Elements Chatbot 组件和 Pi Harness，已启用工具、审批、Skills、项目上下文和系统提示词加载。

## 运行

需要 Node >=22.19（建议 24），以及本人已配置好的 Pi 认证。首次认证可在安装依赖后运行 `npx --no-install pi`，再使用 `/login`。

```bash
npm ci
mkdir -p demo-workspace
```

在 `.env.local` 写入 `PI_WEB_WORKSPACE=./demo-workspace`，然后执行 `npm run dev`，访问 http://127.0.0.1:3000 。

生产运行：`npm run build`，再 `npm start`。

本机 Shell 继承服务进程的权限与环境；它不是容器隔离。本包默认监听回环地址。模型推理位置由供应商端点决定。

## 结构

- `src/components/chat.tsx` 是当前聊天入口；`ai-elements/` 保存原示例组件。
- `src/lib/pi-session.ts` 管理 Harness 原生会话与恢复。
- `src/lib/harness-resources.ts` 发现并加载 Skills、上下文和提示词。
- `src/app/api/chat/route.ts` 处理消息、审批与流。
- `docs/*SOURCES*` 与 `docs/upstream/` 用于组件来源校验。
- `third_party/` 保存上游授权。

## 检查

```bash
npm run typecheck
npm test
npm run verify:ui
npm run build
```

本次资料整理重新通过 typecheck、10 项测试和 verify:ui。build 是此前交付已通过的结果，本次没有重跑。测试使用隔离临时配置和本地模拟模型，不消耗个人供应商配额；不代表所有真实供应商或 MCP 服务已经验收。

`TUTORIAL-SOURCE-MANIFEST.json` 记录文件摘要。包中没有 node_modules、构建缓存、会话数据、个人认证或个人 Skill 原文。完整教学正文作为独立文件与本包一起交付。
